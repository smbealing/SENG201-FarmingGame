package crop;

public class DragonFruit extends Crop {


	/**
	 * The constructor method for a DragonFruit crop.
	 */
    public DragonFruit(){
        super("Dragon Fruit", 2.00, 6.00, 7, 2);

    }
}
