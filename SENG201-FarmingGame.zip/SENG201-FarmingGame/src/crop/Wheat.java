package crop;

public class Wheat extends Crop {

	
	/**
	 * The constructor method for a Wheat crop.
	 */
    public Wheat(){
        super("Wheat", 0.20, 1.00, 5, 7);
    }
}
