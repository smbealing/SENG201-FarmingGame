package crop;
public class Banana extends Crop {


	/**
	 * The constructor method for a Banana crop.
	 */
    public Banana(){
        super("Banana", 1.00, 2.50, 6, 1);
    }

}
