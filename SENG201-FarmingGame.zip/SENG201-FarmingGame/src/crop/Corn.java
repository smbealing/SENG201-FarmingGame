package crop;
public class Corn extends Crop {


	/**
	 * The constructor method for a Corn crop.
	 */
    public Corn(){
        super("Corn", 0.50, 1.50, 4, 1);
    }
}
