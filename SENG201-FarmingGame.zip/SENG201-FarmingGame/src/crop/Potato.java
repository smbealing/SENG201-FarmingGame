package crop;

public class Potato extends Crop {


	/**
	 * The constructor method for a Potato crop.
	 */
    public Potato(){
        super("Potato", 0.50, 1.50, 4, 2);
    }
}
