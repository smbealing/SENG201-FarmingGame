package crop;

public class Tomato extends Crop {


	/**
	 * The constructor method for a Tomato crop.
	 */
    public Tomato(){
        super("Tomato", 0.50, 2.50, 3, 2);
    }
}
