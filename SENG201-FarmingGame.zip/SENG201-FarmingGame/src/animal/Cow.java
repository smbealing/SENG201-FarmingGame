package animal;

public class Cow extends Animal {
	
	/**
	 * The constructor method for a Cow.
	 */
	public Cow() {
		super("Cow", 40.00, 25.00, 100, 100);
	}

}
