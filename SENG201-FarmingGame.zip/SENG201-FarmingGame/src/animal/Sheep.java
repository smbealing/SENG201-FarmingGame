package animal;

public class Sheep extends Animal {
	
	/**
	 * The constructor method for a Sheep.
	 */
	public Sheep() {
		super("Sheep", 20.00, 5.00, 30, 80);
	}

}
