package animal;

public class Horse extends Animal {
	
	/**
	 * The constructor method for a Horse.
	 */
	public Horse() {
		super("Horse", 89.99, 54.00, 150, 50);
	}

}
