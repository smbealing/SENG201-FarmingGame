package item;

public class Carrot extends AnimalFood {
	
	/**
	 * The constructor method for a Carrot.
	 */
	public Carrot() {
		super("Carrot", 5.00, 0, 8);
	}
	
}
