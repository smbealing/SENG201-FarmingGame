package item;
public class Warmth extends GenericItem {
	
	/**
	 * The constructor method for Warmth.
	 */
	public Warmth() {
		super("Warmth", 20.0, 4);
	}
	
}
