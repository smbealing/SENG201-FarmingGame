package item;

public class HighQualityGrain extends AnimalFood {
	
	/**
	 * The constructor method for HighQualityGrain.
	 */
	public HighQualityGrain() {
		super("High Quality Grain", 49.99, 0, 30);
	}

}
