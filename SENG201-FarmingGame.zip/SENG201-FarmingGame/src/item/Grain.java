package item;

public class Grain extends AnimalFood {
	
	/**
	 * The constructor method for Grain.
	 */
	public Grain() {
		super("Grain", 24.99, 0, 15);
	}

}
