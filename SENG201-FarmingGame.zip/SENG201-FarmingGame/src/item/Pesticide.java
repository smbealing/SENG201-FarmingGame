package item;

public class Pesticide extends CropItem {
	
	/**
	 * The constructor method for Pesticide.
	 */
	public Pesticide() {
		super("Pesticide", 20.00, 1, 2);
	}

}
