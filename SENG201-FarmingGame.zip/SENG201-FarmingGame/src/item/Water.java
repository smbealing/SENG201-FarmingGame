package item;

public class Water extends GenericItem {
	
	/**
	 * The constructor method for Water.
	 */
	public Water() {
		super("Water", 0.0, 0);
	}
	
}
