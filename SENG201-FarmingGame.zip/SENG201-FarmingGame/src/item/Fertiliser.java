package item;

public class Fertiliser extends CropItem {
	
	/**
	 * The constructor method for Fertiliser
	 */
	public Fertiliser() {
		super("Fertiliser", 31.60, 0, 4);
	}

}
