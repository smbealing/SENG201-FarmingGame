package item;

public class Speech extends GenericItem {
	
	/**
	 * The constructor method for Speech.
	 */
	public Speech() {
		super("Speech", 0.0, 1);
	}
}
