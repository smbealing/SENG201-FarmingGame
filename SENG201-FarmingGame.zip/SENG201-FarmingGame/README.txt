Open the project from a zipped folder
1. Unzip the file
2. Open eclipse and click on File -> Open Projects from File System...
3. Click on directory and find the project file
4. Select it and click OPEN
5. Click Finish and then the project will open in eclipse

Running the .jar from terminal
1. Make sure Java 11 or higher is installed on the machine 

2. 
Linux:
    Once you have unzipped the folder right click in the folder and select Open in Terminal
Windows:
    Once you have unzipped the folder copy the directory by right clicking the path above you files. Open cmd and write : cd [paste the directory here]

3. Once you are in the directory of the folder run : java -jar smb272_ito16_farming_simulator.jar
Windows:
    If there is an issue running the .jar file from the folder then move the .jar file into a different folder and run the command again from the new location.

4. Enjoy the game
